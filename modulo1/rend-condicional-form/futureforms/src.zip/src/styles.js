import styled from 'styled-components';

export const Container = styled.div`
    position: relative;
    height: 50vh;

    width: 50vh;
    border: 1px solid black;

    left: 50vh;
    top: 25vh;
    
`;

export const Form = styled.div`
    position: absolute;
    text-align: center;
`;