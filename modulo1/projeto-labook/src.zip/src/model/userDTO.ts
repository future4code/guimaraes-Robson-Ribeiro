export interface UserInputDTO {
    id: string,
    name: string,
    email: string,
    password: string
}