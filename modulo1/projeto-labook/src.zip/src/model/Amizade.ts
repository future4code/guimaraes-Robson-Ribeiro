export type Amizade ={
    id: string,
    idUsuarioSolicitante: string,
    idUsuarioAmigo: string,
    createdAt: Date
}