export interface IAmizadeInputDTO {
    id: string,
    idUsuarioSolicitante: string,
    idUsuarioAmigo: string,
    createdAt: Date
}

