export enum POST_TYPES {
    NORMAL = "normal",
    EVENT = "event"
 }