export type authenticationData = {
    id: string
 }
 