###ex01
<h1>a) 
Salt é o custo do fator, controla quanto de tempo é necessário para calcular um único BCrypt. Quanto maior o custo do fator, mais rounds serão necessários. Aumentando em 1, dobra o tempo. Usei doce, por motivos de segurança. </h1>
<h1>

b) Será o HASH junto com a string. </h1>

###ex02
<h1>a) No cadastro, antes de gerar o login e depois gerar o ID.</h1>